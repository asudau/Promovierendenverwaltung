<?php

class DoktorandenverwaltungAddTable extends Migration
{
    public function description()
    {
        return 'Add DB table for Doktorandenverwaltung';
    }

    public function up()
    {
        $role = new Role();
        $role->setRolename('Doktorandenverwaltung');
        $role->setSystemtype(false);
        RolePersistence::saveRole($role);
        
        $db = DBManager::get();

        // add db-table
        $db->exec("CREATE TABLE IF NOT EXISTS `doktorandenverwaltung` (
            `id` int(11) NOT NULL,
            `berichtseinheitid` int(11) NOT NULL DEFAULT '5300000',
            `ef001` int(11) NOT NULL DEFAULT '3',
            `ef002` int(11) DEFAULT NULL,
            `ef003` int(11) NOT NULL DEFAULT '530',
            `ef004` int(11) DEFAULT NULL,
            `ef005` int(11) DEFAULT NULL,
            `ef006u1` int(11) DEFAULT NULL,
            `ef006u2` int(11) DEFAULT NULL,
            `ef006u3` int(11) DEFAULT NULL,
            `ef007` int(11) DEFAULT NULL,
            `ef008` int(11) DEFAULT NULL,
            `ef009` int(11) DEFAULT NULL,
            `ef010` int(11) DEFAULT NULL,
            `ef011` int(11) DEFAULT NULL,
            `ef012` int(11) DEFAULT NULL,
            `ef013u1` int(11) DEFAULT NULL,
            `ef013u2` int(11) DEFAULT NULL,
            `ef014u1` int(11) DEFAULT NULL,
            `ef014u2` int(11) DEFAULT NULL,
            `ef015` int(11) DEFAULT NULL,
            `ef016` int(11) DEFAULT NULL,
            `ef017` int(11) DEFAULT NULL,
            `ef018` int(11) DEFAULT NULL,
            `ef019` int(11) DEFAULT NULL,
            `ef020` int(11) DEFAULT NULL,
            `ef021` int(11) DEFAULT NULL,
            `ef022` int(11) DEFAULT NULL,
            `ef023` int(11) DEFAULT NULL,
            `ef024` int(11) DEFAULT NULL,
            `ef025` int(11) DEFAULT NULL,
            `ef026` int(11) DEFAULT NULL,
            `ef027` int(11) DEFAULT NULL,
            `ef028` int(11) DEFAULT NULL,
            `ef029` int(11) DEFAULT NULL,
            `ef030` int(11) DEFAULT NULL,
            `ef031` int(11) DEFAULT NULL,
            `ef032` int(11) DEFAULT NULL,
            `ef033u1` int(11) DEFAULT NULL,
            `ef033u2` int(11) DEFAULT NULL,
            `ef034` int(11) DEFAULT NULL,
            `ef035` int(11) DEFAULT NULL,
            `ef036` int(11) DEFAULT NULL,
            `ef037` int(11) DEFAULT NULL,
            `ef038` int(11) DEFAULT NULL,
            `chdate` int(11) DEFAULT NULL,
            PRIMARY KEY (id)
        ) ");

        SimpleORMap::expireTableScheme();
    }

    public function down()
    {
        $db = DBManager::get();

        $db->exec("DROP TABLE doktorandenverwaltung");

        SimpleORMap::expireTableScheme();
    }
}
